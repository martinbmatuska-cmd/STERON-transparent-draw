import styles from './styles.css?inline';
import cinzelLatinExt600 from '@fontsource/cinzel/files/cinzel-latin-ext-600-normal.woff2?url';
import cinzelLatin600 from '@fontsource/cinzel/files/cinzel-latin-600-normal.woff2?url';
import { APP_CONFIG, assertAllowedStaticUrl, resolveStaticUrl } from './config.js';
import {
  DrawIntegrityError,
  computeDraw,
  getCountdownState,
  validateDrawConfig,
  verifyEntries,
} from './draw-engine.js';
import {
  DrandUnavailableError,
  DrandVerificationError,
  fetchVerifiedBeacon,
} from './drand-client.js';

const FONT_FACE_STYLES = `
  @font-face {
    font-family: "Steron Display";
    font-style: normal;
    font-display: swap;
    font-weight: 600;
    src: url("${cinzelLatinExt600}") format("woff2");
    unicode-range: U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF;
  }
  @font-face {
    font-family: "Steron Display";
    font-style: normal;
    font-display: swap;
    font-weight: 600;
    src: url("${cinzelLatin600}") format("woff2");
    unicode-range: U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;
  }
`;

const INFO_CONTENT = {
  entries: {
    eyebrow: 'VSTUPY',
    title: '24 platných vstupov',
    text: 'Verejný zoznam obsahuje iba kódy ST-01 až ST-24. Každý kód bol ešte pred žrebovaním pridelený ku konkrétnemu Facebook komentáru; mená sa do tejto stránky neukladajú.',
    bullets: ['24 jedinečných kódov', 'žiadne osobné mená', 'poradie vstupov je vopred uzamknuté'],
    section: 'inputs',
  },
  locked: {
    eyebrow: 'ZÁVÄZOK',
    title: 'Zamknutý zoznam',
    text: 'Presné bajty súboru entries.txt majú verejne zobrazený SHA-256 odtlačok. Zmena jediného znaku vytvorí iný hash a stránka výsledok bezpečne odmietne zobraziť.',
    bullets: ['UTF-8 a riadky LF', 'presne jeden kód na riadok', 'kontrola pred každým výpočtom'],
    section: 'inputs',
  },
  drand: {
    eyebrow: 'VEREJNÁ NÁHODA',
    title: 'Drand Quicknet',
    text: 'Drand je verejný distribuovaný randomness beacon. Stránka čaká na presne určený budúci round a kryptograficky overí jeho BLS podpis proti uzamknutému verejnému kľúču.',
    bullets: ['nie je to blockchain', 'autor nevie budúcu hodnotu vybrať', 'výpadok relaya nemení round'],
    section: 'drand',
  },
  method: {
    eyebrow: 'OTVORENÝ POSTUP',
    title: 'Bez tlačidla „Žrebovať“',
    text: 'Po zverejnení beaconu vznikne zo seedu celé poradie cez Fisher–Yates shuffle. Rejection sampling odstráni modulo bias; prvý kód je výherca a ďalšie kódy sú náhradníci.',
    bullets: ['žiadna lokálna náhoda', 'deterministické celé poradie', 'výsledok možno nezávisle prepočítať'],
    section: 'algorithm',
  },
};

const icon = (path) => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${path}"/></svg>`;
const ICONS = {
  entries: icon('M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75'),
  locked: icon('M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10ZM9 12l2 2 4-4'),
  drand: icon('M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6'),
  method: icon('M4 4h16v16H4zM8 9h8M8 13h5M8 17h3'),
  arrow: icon('M5 12h14M13 6l6 6-6 6'),
  close: icon('M6 6l12 12M18 6 6 18'),
};

function appTemplate() {
  return `
    <style>${FONT_FACE_STYLES}${styles}</style>
    <div class="app" data-phase="loading">
      <div class="media-stage" aria-hidden="true"></div>
      <div class="atmosphere" aria-hidden="true"></div>

      <header class="site-header">
        <a class="brand" data-route="home" aria-label="STERON – domov">
          <span class="brand-word" aria-hidden="true"><span>STER</span><span class="brand-eye-symbol"><img src="${APP_CONFIG.branding.eyeImage}" alt=""></span><span>N</span></span>
          <span class="brand-tagline" aria-hidden="true">VIAC NEŽ REALITA</span>
        </a>
        <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="steron-nav" aria-label="Otvoriť menu">
          <span></span><span></span><span></span>
        </button>
        <nav class="main-nav" id="steron-nav" aria-label="Hlavná navigácia">
          <a data-route="home">DOMOV</a>
          <a data-route="project">O PROJEKTE</a>
          <a data-route="shop">OBCHOD</a>
          <a data-route="vip">VIP</a>
          <a class="is-active" href="#draw" aria-current="page">ŽREBOVANIE</a>
        </nav>
        <a class="support-link" data-route="support" title="Vstup do STERON Projektu na viac platieb" aria-label="Vstup do STERON Projektu na viac platieb">
          <span>PODPORIŤ STERON</span>${ICONS.arrow}
        </a>
      </header>

      <main class="hero" id="draw">
        <div class="hero-grid">
          <section class="hero-copy" aria-labelledby="page-title">
            <p class="eyebrow">STERON / OVERITEĽNÝ VÝSLEDOK</p>
            <h1 id="page-title" aria-label="Transparentné žrebovanie">
              <span class="hero-overline" aria-hidden="true">TRANSPARENTNÉ</span>
              <span class="hero-title-word" aria-hidden="true"><span>ŽREB</span><span class="hero-eye-symbol"><img src="${APP_CONFIG.branding.eyeImage}" alt=""></span><span>VANIE</span></span>
            </h1>
            <p class="hero-lead">Skutoční ľudia. Férové podmienky. Overiteľný výsledok.</p>
            <p class="hero-intro">24 vopred pridelených kódov. Jeden presne určený verejný beacon. Bez zásahu autora do výsledku.</p>

            <section class="draw-card" aria-labelledby="draw-card-title">
              <div class="phase-announcement sr-only" aria-live="polite" aria-atomic="true"></div>
              <div class="state-view loading-view">
                <div class="spinner" aria-hidden="true"></div>
                <div><p class="state-kicker">KONTROLA ZÁVÄZKU</p><h2 id="draw-card-title">Overujem konfiguráciu a vstupy…</h2></div>
              </div>

              <div class="state-view countdown-view" hidden>
                <p class="state-kicker">ŽREBOVANIE SA USKUTOČNÍ O</p>
                <div class="countdown" aria-hidden="true">
                  <div><strong data-count="days">00</strong><span>DNI</span></div>
                  <i>:</i>
                  <div><strong data-count="hours">00</strong><span>HODINY</span></div>
                  <i>:</i>
                  <div><strong data-count="minutes">00</strong><span>MINÚTY</span></div>
                  <i>:</i>
                  <div><strong data-count="seconds">00</strong><span>SEKUNDY</span></div>
                </div>
                <p class="countdown-accessible sr-only">Žrebovanie sa uskutoční 18. septembra 2026 o 18:30 stredoeurópskeho letného času.</p>
              </div>

              <div class="state-view waiting-view" hidden>
                <div class="spinner beacon-spinner" aria-hidden="true"></div>
                <div>
                  <p class="state-kicker">ČAS ŽREBOVANIA NASTAL</p>
                  <h2>Overujem verejnú náhodu…</h2>
                  <p class="state-copy">Čakáme na kryptograficky overený verejný beacon. Výsledok sa nemení — čakáme iba na zverejnenie vopred určeného roundu.</p>
                  <p class="retry-note" data-retry-note></p>
                </div>
              </div>

              <div class="state-view result-view" hidden>
                <div class="result-heading">
                  <div><p class="state-kicker">VÝSLEDOK ŽREBOVANIA</p><h2>Výherný kód</h2></div>
                  <span class="verified-badge">Kryptograficky overené <b>✓</b></span>
                </div>
                <strong class="winner-code" data-winner>ST-XX</strong>
                <p class="alternate">1. náhradník: <strong data-alternate>ST-YY</strong></p>
                <div class="result-actions">
                  <button type="button" class="text-button" data-open-order disabled>Zobraziť úplné poradie</button>
                  <button type="button" class="text-button" data-reverify disabled>Overiť výsledok</button>
                </div>
              </div>

              <div class="state-view error-view" hidden>
                <span class="error-mark" aria-hidden="true">!</span>
                <div>
                  <p class="state-kicker">BEZPEČNÉ ZASTAVENIE</p>
                  <h2>Overenie údajov zlyhalo</h2>
                  <p class="state-copy">Výsledok nebude zobrazený, kým sa nepodarí overiť presne vopred určené údaje.</p>
                  <p class="error-code" data-error-code></p>
                </div>
              </div>

              <div class="draw-meta" aria-label="Parametre žrebovania">
                <span><b>18. 9. 2026</b><small>18:30 SELČ</small></span>
                <span><b>DRAND QUICKNET</b><small>Round 32 315 212</small></span>
                <span><b>24</b><small>PLATNÝCH VSTUPOV</small></span>
              </div>
            </section>

            <div class="trust-cards" aria-label="Vlastnosti žrebovania">
              ${Object.entries(INFO_CONTENT).map(([key, item]) => `
                <article class="trust-card" data-card="${key}">
                  <span class="card-icon">${ICONS[key]}</span>
                  <div><strong>${item.title}</strong><small>${item.eyebrow}</small></div>
                  <button type="button" class="info-button" data-info="${key}" aria-label="Viac informácií: ${item.title}" aria-expanded="false" aria-controls="card-popover">i</button>
                </article>`).join('')}
            </div>

            <div class="hero-actions">
              <a class="primary-cta" data-route="project"><span>OBJAV STERON PROJEKT</span>${ICONS.arrow}</a>
              <button class="secondary-cta" type="button" data-open-audit>AKO TO FUNGUJE?</button>
              <a class="shop-link" data-route="shop">OBCHOD</a>
            </div>
            <div class="control-links" aria-label="Kontrolné údaje žrebovania">
              <button type="button" data-open-entries>Zobraziť vstupy</button>
              <button type="button" data-open-archive>Archív žrebovaní</button>
              <span>v${APP_CONFIG.release.version} · ${APP_CONFIG.release.publicationLabel}</span>
              <a data-release-manifest target="_blank" rel="noopener" title="Verejný release manifest a checksumy nasadeného buildu">Release manifest</a>
            </div>
          </section>

          <aside class="author-note" aria-label="Odkaz autora">
            <blockquote>„Nie je to istota.<br>Je to skúška odvahy.“</blockquote>
            <p class="author-signature">Martin Matuška</p>
            <p class="handwritten">Ďakujem, že tvoríte<br>STERON spolu so mnou.</p>
            <button class="media-toggle" type="button" data-media-toggle hidden aria-pressed="false">
              <span class="media-toggle-icon" aria-hidden="true"></span>
              <span data-media-toggle-label>Pozastaviť pozadie</span>
            </button>
          </aside>
        </div>
      </main>

      <footer class="site-footer">
        <span>STERON</span><i></i><span>TVORÍME REALITU</span><i></i><span>ĽUDIA</span><i></i><span>SLOBODA</span><i></i><span>PRÍLEŽITOSTI</span>
      </footer>

      <div class="popover-backdrop" data-popover-backdrop hidden></div>
      <section class="info-popover" id="card-popover" role="dialog" aria-modal="false" aria-labelledby="popover-title" hidden>
        <button class="icon-close" type="button" data-close-popover aria-label="Zavrieť informácie">${ICONS.close}</button>
        <p class="popover-eyebrow" data-popover-eyebrow></p>
        <h2 id="popover-title" data-popover-title></h2>
        <p data-popover-text></p>
        <ul data-popover-list></ul>
        <button type="button" class="deep-link" data-popover-deep>Otvoriť technické detaily ${ICONS.arrow}</button>
      </section>

      <dialog class="audit-dialog" data-audit-dialog aria-labelledby="audit-title">
        <div class="dialog-shell">
          <header class="dialog-header">
            <div><p class="dialog-eyebrow">NEZÁVISLE PREPOČÍTATEĽNÉ</p><h2 id="audit-title">Ako žrebovanie funguje</h2></div>
            <button class="icon-close" type="button" data-close-dialog aria-label="Zavrieť technické detaily">${ICONS.close}</button>
          </header>
          <div class="dialog-intro">
            <p>Kód ani autor neurčujú výsledok. V čase uzamknutia vstupov ešte verejná náhoda neexistovala.</p>
            <span data-audit-status>Konfigurácia sa overuje…</span>
          </div>
          <div class="audit-sections">
            <section data-audit-section="inputs">
              <span class="section-number">A</span><div>
                <h3>Vstupy</h3>
                <dl>
                  <div><dt>Počet</dt><dd data-audit-entry-count>24</dd></div>
                  <div><dt>SHA-256 entries.txt</dt><dd><code data-audit-entries-hash>—</code></dd></div>
                  <div><dt>Kanonický formát</dt><dd>UTF-8 bez BOM · LF · jeden kód na riadok · jeden záverečný LF</dd></div>
                </dl>
                <p>V tomto webe nie sú mená. Kódy ST-01 až ST-24 boli verejne priradené ku komentárom pred žrebovaním. SHA-256 je kryptografický odtlačok: ak sa zmení čo i len jeden bajt, kontrola zlyhá.</p>
              </div>
            </section>
            <section data-audit-section="drand">
              <span class="section-number">B</span><div>
                <h3>Drand</h3>
                <dl>
                  <div><dt>Sieť</dt><dd>League of Entropy mainnet Quicknet</dd></div>
                  <div><dt>Chain hash</dt><dd><code data-audit-chain-hash>—</code></dd></div>
                  <div><dt>Round</dt><dd data-audit-round>32 315 212</dd></div>
                  <div><dt>Timestamp</dt><dd data-audit-timestamp>2026-09-18T16:30:00.000Z</dd></div>
                  <div><dt>Randomness</dt><dd><code data-audit-randomness>Čaká na zverejnenie roundu</code></dd></div>
                  <div><dt>Signature</dt><dd><code data-audit-signature>Čaká na zverejnenie roundu</code></dd></div>
                  <div><dt>Verification</dt><dd data-audit-verification>Čaká na beacon</dd></div>
                </dl>
                <p>Drand nie je blockchain. Je to verejný distribuovaný randomness beacon. Oficiálny klient kontroluje BLS podpis, väzbu randomness na podpis, sieťový kľúč aj presný round. Relay môže odpoveď zdržať, ale nevie vytvoriť platný iný výsledok.</p>
              </div>
            </section>
            <section data-audit-section="seed">
              <span class="section-number">C</span><div>
                <h3>Seed</h3>
                <p>Presný UTF-8 vstup do SHA-256 (bez záverečného newline):</p>
                <pre data-audit-seed-material>STERON-DRAW-v1\n&lt;entriesHash&gt;\n&lt;chainHash&gt;\n32315212\n&lt;drandRandomness&gt;</pre>
                <dl><div><dt>Final seed SHA-256</dt><dd><code data-audit-final-seed>Čaká na beacon</code></dd></div></dl>
              </div>
            </section>
            <section data-audit-section="algorithm">
              <span class="section-number">D</span><div>
                <h3>Algoritmus</h3>
                <p>Z final seedu vzniká SHA-256 byte stream: každý 32-bajtový blok je SHA-256(rawFinalSeed || uint64be(counter)), counter začína nulou. Fisher–Yates prechádza zoznam odzadu. Každý index vyberá rejection sampling z big-endian uint32.</p>
                <p>Hodnoty nad najväčším násobkom aktuálneho rozsahu menším než 2³² sa zahodia. Preto niektoré indexy nedostávajú vyššiu pravdepodobnosť — nevzniká modulo bias. Nepoužíva sa Math.random(), crypto.getRandomValues(), čas prehliadača ani serverová náhoda.</p>
              </div>
            </section>
            <section data-audit-section="result">
              <span class="section-number">E</span><div>
                <h3>Výsledok</h3>
                <dl>
                  <div><dt>Výherný kód</dt><dd data-audit-winner>Čaká na beacon</dd></div>
                  <div><dt>Úplné poradie</dt><dd data-audit-order>Čaká na beacon</dd></div>
                </dl>
                <p>Pri výpadku API sa nemení round ani algoritmus. Stránka skúša ďalší oficiálny relay a čaká. Ak nesedí hash, round alebo podpis, výsledok sa vôbec nezobrazí.</p>
                <button class="copy-button" type="button" data-copy-audit disabled>Skopírovať audit</button>
              </div>
            </section>
          </div>
        </div>
      </dialog>

      <dialog class="order-dialog" data-order-dialog aria-labelledby="order-title">
        <div class="dialog-shell order-shell">
          <header class="dialog-header"><div><p class="dialog-eyebrow">DETERMINISTICKÁ PERMUTÁCIA</p><h2 id="order-title">Úplné poradie</h2></div><button class="icon-close" type="button" data-close-dialog aria-label="Zavrieť úplné poradie">${ICONS.close}</button></header>
          <p class="order-intro">Pozícia 1 je výherca. Pozície 2 až 24 tvoria nemenné poradie náhradníkov.</p>
          <ol class="full-order" data-full-order></ol>
        </div>
      </dialog>

      <dialog class="entries-dialog" data-entries-dialog aria-labelledby="entries-title">
        <div class="dialog-shell compact-dialog-shell">
          <header class="dialog-header"><div><p class="dialog-eyebrow">OVERENÝ SÚBOR ENTRIES.TXT</p><h2 id="entries-title">Platné vstupy</h2></div><button class="icon-close" type="button" data-close-dialog aria-label="Zavrieť zoznam vstupov">${ICONS.close}</button></header>
          <div class="dialog-intro entries-intro">
            <p>Presný verejný zoznam obsahuje iba kódy. Mená nie sú v tomto webe uložené.</p>
            <span data-entries-status>Vstupy sa overujú…</span>
          </div>
          <ol class="entry-list" data-entry-list aria-label="Kódy ST-01 až ST-24"></ol>
          <div class="dialog-actions">
            <button class="copy-button" type="button" data-copy-entries disabled>Kopírovať zoznam</button>
            <a class="copy-button button-link" data-download-entries download="entries.txt">Stiahnuť entries.txt</a>
          </div>
          <p class="provenance-note"><strong>Zdroj/verzia:</strong> <span data-source-version>${APP_CONFIG.release.sourceVersion}</span><br><strong>Stav publikácie:</strong> ${APP_CONFIG.release.publicationLabel}. Verejný záväzok je dostupný v zdrojovom repozitári a release manifeste.</p>
        </div>
      </dialog>

      <dialog class="archive-dialog" data-archive-dialog aria-labelledby="archive-title">
        <div class="dialog-shell compact-dialog-shell">
          <header class="dialog-header"><div><p class="dialog-eyebrow">HISTÓRIA</p><h2 id="archive-title">Archív žrebovaní</h2></div><button class="icon-close" type="button" data-close-dialog aria-label="Zavrieť archív žrebovaní">${ICONS.close}</button></header>
          <div class="empty-state" data-archive-empty>
            <span aria-hidden="true">01</span>
            <h3>Zatiaľ bez archivovaných žrebovaní</h3>
            <p>Aktívne je prvé žrebovanie. Po budúcej súťaži možno pridať overený statický záznam bez databázy a bez vytvárania falošných výsledkov.</p>
          </div>
          <ol class="archive-list" data-archive-list hidden></ol>
        </div>
      </dialog>

      <div class="toast" role="status" aria-live="polite" aria-atomic="true" data-toast hidden></div>
    </div>`;
}

function pad(value) {
  return String(value).padStart(2, '0');
}

function delay(ms, signal) {
  if (signal?.aborted) return Promise.reject(new DOMException('Operácia bola zrušená.', 'AbortError'));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(timer);
      reject(new DOMException('Operácia bola zrušená.', 'AbortError'));
    };
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

function isRetryableStaticStatus(status) {
  return status === 408 || status === 429 || status >= 500;
}

function abortedOperation() {
  return new DOMException('Operácia bola zrušená.', 'AbortError');
}

async function readResponseBytes(response, signal) {
  if (!response.body) return new Uint8Array();
  const reader = response.body.getReader();
  const chunks = [];
  let byteLength = 0;
  let rejectAbort;
  const abortPromise = new Promise((resolve, reject) => { rejectAbort = reject; });
  const onAbort = () => rejectAbort(abortedOperation());
  if (signal.aborted) onAbort();
  else signal.addEventListener('abort', onAbort, { once: true });
  try {
    while (true) {
      const { done, value } = await Promise.race([reader.read(), abortPromise]);
      if (done) break;
      chunks.push(value);
      byteLength += value.byteLength;
    }
  } catch (error) {
    reader.cancel(error).catch(() => {});
    throw error;
  } finally {
    signal.removeEventListener('abort', onAbort);
    try { reader.releaseLock(); } catch { /* A pending read is cancelled asynchronously. */ }
  }
  const bytes = new Uint8Array(byteLength);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}

async function staticBytes(url, { accept, label, code, signal }) {
  const { requestTimeoutMs, retryScheduleMs } = APP_CONFIG.staticData;
  const testTimeout = import.meta.env.DEV
    ? Number(window.__STERON_DRAW_TEST_HOOKS__?.staticRequestTimeoutMs)
    : Number.NaN;
  const bodyTimeoutMs = Number.isFinite(testTimeout) && testTimeout > 0
    ? testTimeout
    : requestTimeoutMs;
  let lastFailure;
  for (const waitMs of retryScheduleMs) {
    await delay(waitMs, signal);
    const requestController = new AbortController();
    const abortRequest = () => requestController.abort();
    signal?.addEventListener('abort', abortRequest, { once: true });
    // The deadline covers headers *and* complete body consumption. A 200
    // response with a stalled stream must not hold the draw in loading forever.
    const timeout = setTimeout(() => requestController.abort(), bodyTimeoutMs);
    try {
      const response = await fetch(url, {
        cache: 'no-store',
        headers: { Accept: accept },
        signal: requestController.signal,
      });
      if (response.ok) return await readResponseBytes(response, requestController.signal);
      if (!isRetryableStaticStatus(response.status)) {
        throw new DrawIntegrityError(`${label} sa nepodarilo načítať (HTTP ${response.status}).`, `${code}_FETCH`);
      }
      lastFailure = new Error(`HTTP ${response.status}`);
    } catch (error) {
      if (signal?.aborted) throw new DOMException('Operácia bola zrušená.', 'AbortError');
      if (error instanceof DrawIntegrityError) throw error;
      lastFailure = error;
    } finally {
      clearTimeout(timeout);
      signal?.removeEventListener('abort', abortRequest);
    }
  }
  throw new DrawIntegrityError(`${label} je po opakovaných pokusoch nedostupný.`, `${code}_UNAVAILABLE`, { cause: lastFailure });
}

async function jsonResponse(url, { label, code, signal }) {
  const bytes = await staticBytes(url, { accept: 'application/json', label, code, signal });
  try {
    return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
  } catch {
    throw new DrawIntegrityError(`${label} nie je platné JSON.`, `${code}_JSON`);
  }
}

class SteronDrawApp extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = appTemplate();
    this.clockTimer = null;
    this.runToken = 0;
    this.config = null;
    this.entriesData = null;
    this.beacon = null;
    this.result = null;
    this.manifest = null;
    this.entriesUrl = null;
    this.activeInfoTrigger = null;
    this.popoverTimer = null;
    this.toastTimer = null;
    this.buttonTimer = null;
    this.lastDialogTrigger = null;
    this.lifecycleController = null;
    this.mediaController = null;
    this.backgroundVideo = null;
    this.backgroundPausedByUser = false;
    this.connectionToken = 0;
    this.pointerDownTrigger = null;
    this.suppressPopoverFocus = false;
    this.lastAnnouncement = '';
    this.mobileMedia = matchMedia('(max-width: 760px) and (orientation: portrait)');
    this.reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
    this.finePointer = matchMedia('(hover: hover) and (pointer: fine)');
    const hooks = import.meta.env.DEV ? window.__STERON_DRAW_TEST_HOOKS__ : undefined;
    this.now = hooks?.now || (() => Date.now());
    this.beaconFetcher = hooks?.fetchVerifiedBeacon || fetchVerifiedBeacon;
    this.onTestState = hooks?.onStateChange || (() => {});
  }

  connectedCallback() {
    this.lifecycleController?.abort();
    this.lifecycleController = new AbortController();
    const { signal } = this.lifecycleController;
    const connectionToken = ++this.connectionToken;
    this.bindLinks();
    this.bindUi(signal);
    this.renderMedia();
    this.mobileMedia.addEventListener('change', this.handleMediaChange, { signal });
    this.reducedMotion.addEventListener('change', this.handleMediaChange, { signal });
    window.addEventListener('resize', this.handleViewportChange, { signal });
    window.addEventListener('orientationchange', this.handleViewportChange, { signal });
    this.loadLockedDraw(connectionToken, signal);
  }

  disconnectedCallback() {
    clearInterval(this.clockTimer);
    clearTimeout(this.popoverTimer);
    clearTimeout(this.toastTimer);
    clearTimeout(this.buttonTimer);
    this.runToken += 1;
    this.connectionToken += 1;
    this.closePopover(false);
    this.disposeMedia();
    this.lifecycleController?.abort();
    this.lifecycleController = null;
  }

  handleMediaChange = () => this.renderMedia();

  handleViewportChange = () => {
    const popover = this.shadowRoot.querySelector('.info-popover');
    if (popover.hidden || !this.activeInfoTrigger) return;
    if (this.finePointer.matches) this.positionPopover(this.activeInfoTrigger, popover);
    else this.clearPopoverPosition(popover);
  };

  bindLinks() {
    this.shadowRoot.querySelectorAll('[data-route]').forEach((element) => {
      const href = APP_CONFIG.links[element.dataset.route];
      if (href) element.href = href;
    });
    this.shadowRoot.querySelector('[data-release-manifest]').href = resolveStaticUrl(APP_CONFIG.staticData.releaseManifestPath);
  }

  bindUi(signal) {
    const root = this.shadowRoot;
    const menuButton = root.querySelector('.menu-toggle');
    const nav = root.querySelector('.main-nav');
    const on = (target, type, handler, options = {}) => target.addEventListener(type, handler, { ...options, signal });
    on(menuButton, 'click', () => {
      const open = menuButton.getAttribute('aria-expanded') !== 'true';
      menuButton.setAttribute('aria-expanded', String(open));
      menuButton.setAttribute('aria-label', open ? 'Zavrieť menu' : 'Otvoriť menu');
      nav.classList.toggle('is-open', open);
    });
    on(nav, 'click', () => {
      menuButton.setAttribute('aria-expanded', 'false');
      nav.classList.remove('is-open');
    });

    on(root.querySelector('[data-open-audit]'), 'click', (event) => this.openDialog(root.querySelector('[data-audit-dialog]'), event.currentTarget));
    on(root.querySelector('[data-open-order]'), 'click', (event) => this.openOrder(event.currentTarget));
    on(root.querySelector('[data-reverify]'), 'click', (event) => this.reverify(event.currentTarget));
    on(root.querySelector('[data-copy-audit]'), 'click', (event) => this.copyAudit(event.currentTarget));
    on(root.querySelector('[data-open-entries]'), 'click', (event) => this.openDialog(root.querySelector('[data-entries-dialog]'), event.currentTarget));
    on(root.querySelector('[data-open-archive]'), 'click', (event) => this.openDialog(root.querySelector('[data-archive-dialog]'), event.currentTarget));
    on(root.querySelector('[data-copy-entries]'), 'click', (event) => this.copyEntries(event.currentTarget));
    on(root.querySelector('[data-media-toggle]'), 'click', () => this.toggleBackgroundMedia());
    root.querySelectorAll('[data-close-dialog]').forEach((button) => on(button, 'click', () => this.closeDialog(button.closest('dialog'))));
    root.querySelectorAll('dialog').forEach((dialog) => {
      on(dialog, 'click', (event) => {
        if (event.target === dialog) this.closeDialog(dialog);
      });
      on(dialog, 'close', () => {
        const trigger = this.lastDialogTrigger;
        this.lastDialogTrigger = null;
        this.restoreFocus(trigger);
      });
    });

    root.querySelectorAll('[data-info]').forEach((button) => {
      on(button, 'pointerdown', () => {
        this.pointerDownTrigger = button;
      });
      on(button, 'click', (event) => {
        event.stopPropagation();
        this.openPopover(button, true);
        this.pointerDownTrigger = null;
      });
      on(button, 'mouseenter', () => {
        if (this.finePointer.matches) this.openPopover(button, false);
      });
      on(button, 'focus', () => {
        if (!this.suppressPopoverFocus && this.pointerDownTrigger !== button) this.openPopover(button, false);
      });
      on(button, 'pointercancel', () => { this.pointerDownTrigger = null; });
      on(button, 'mouseleave', () => this.schedulePopoverClose());
      on(button.closest('.trust-card'), 'mouseleave', () => this.schedulePopoverClose());
    });
    const popover = root.querySelector('.info-popover');
    on(popover, 'mouseenter', () => clearTimeout(this.popoverTimer));
    on(popover, 'mouseleave', () => this.schedulePopoverClose());
    on(root.querySelector('[data-close-popover]'), 'click', () => this.closePopover(true));
    on(root.querySelector('[data-popover-backdrop]'), 'click', () => this.closePopover(true));
    on(root.querySelector('[data-popover-deep]'), 'click', () => {
      const section = root.querySelector('[data-popover-deep]').dataset.section;
      const trigger = this.activeInfoTrigger;
      this.closePopover(false);
      this.openDialog(root.querySelector('[data-audit-dialog]'), trigger);
      requestAnimationFrame(() => root.querySelector(`[data-audit-section="${section}"]`)?.scrollIntoView({ block: 'start' }));
    });
    on(root, 'pointerdown', (event) => {
      if (!this.activeInfoTrigger || popover.hidden) return;
      if (event.target === root.querySelector('[data-popover-backdrop]')) return;
      if (!popover.contains(event.target) && !event.composedPath().includes(this.activeInfoTrigger)) this.closePopover(false);
    });
    on(root, 'focusout', () => {
      requestAnimationFrame(() => {
        if (popover.hidden) return;
        const focused = root.activeElement;
        if (focused === this.activeInfoTrigger || popover.contains(focused)) return;
        this.closePopover(false);
      });
    });
    on(document, 'keydown', (event) => {
      if (event.key === 'Escape' && !popover.hidden) this.closePopover(true);
    }, { capture: true });
    on(root, 'keydown', (event) => {
      if (event.key !== 'Escape') return;
      if (nav.classList.contains('is-open')) {
        nav.classList.remove('is-open');
        menuButton.setAttribute('aria-expanded', 'false');
        menuButton.focus();
      }
    });
  }

  disposeMedia() {
    this.mediaController?.abort();
    this.mediaController = null;
    const video = this.backgroundVideo;
    this.backgroundVideo = null;
    if (!video) return;
    video.pause();
    video.removeAttribute('src');
    video.querySelectorAll('source').forEach((source) => source.removeAttribute('src'));
    try { video.load(); } catch { /* Detached media cleanup is best effort. */ }
  }

  setMediaToggle(playing) {
    const button = this.shadowRoot.querySelector('[data-media-toggle]');
    button.hidden = false;
    button.setAttribute('aria-pressed', String(!playing));
    button.querySelector('[data-media-toggle-label]').textContent = playing ? 'Pozastaviť pozadie' : 'Prehrať pozadie';
  }

  async toggleBackgroundMedia() {
    const video = this.backgroundVideo;
    if (!video) return;
    if (video.paused) {
      this.backgroundPausedByUser = false;
      try {
        await video.play();
        this.setMediaToggle(true);
      } catch {
        this.setMediaToggle(false);
      }
      return;
    }
    this.backgroundPausedByUser = true;
    video.pause();
    this.setMediaToggle(false);
  }

  renderMedia() {
    const stage = this.shadowRoot.querySelector('.media-stage');
    const app = this.shadowRoot.querySelector('.app');
    const toggle = this.shadowRoot.querySelector('[data-media-toggle]');
    const portrait = this.mobileMedia.matches;
    const variant = portrait ? APP_CONFIG.media.mobile : APP_CONFIG.media.desktop;
    this.disposeMedia();
    stage.replaceChildren();
    stage.dataset.variant = portrait ? 'mobile' : 'desktop';
    app.dataset.media = 'image';
    toggle.hidden = true;

    const image = document.createElement('img');
    image.className = 'media-poster';
    image.src = variant.image;
    image.alt = '';
    image.loading = 'eager';
    image.decoding = 'async';
    image.fetchPriority = 'high';
    stage.append(image);

    if (this.reducedMotion.matches || (!variant.videoWebm && !variant.videoMp4)) return;

    const video = document.createElement('video');
    video.className = 'media-video';
    video.autoplay = !this.backgroundPausedByUser;
    video.loop = true;
    video.muted = true;
    video.defaultMuted = true;
    video.playsInline = true;
    video.preload = 'auto';
    video.poster = variant.image;
    video.setAttribute('aria-hidden', 'true');
    const mediaSources = [];
    if (variant.videoWebm) {
      const source = document.createElement('source');
      source.src = variant.videoWebm;
      source.type = 'video/webm';
      video.append(source);
      mediaSources.push(source);
    }
    if (variant.videoMp4) {
      const source = document.createElement('source');
      source.src = variant.videoMp4;
      source.type = 'video/mp4';
      video.append(source);
      mediaSources.push(source);
    }
    stage.append(video);
    app.dataset.media = 'video';
    this.backgroundVideo = video;
    this.mediaController = new AbortController();
    const { signal } = this.mediaController;
    const markRenderedFrame = () => {
      if (video !== this.backgroundVideo) return;
      const showVideo = () => {
        if (video !== this.backgroundVideo) return;
        video.dataset.frameReady = 'true';
        video.classList.add('is-rendering');
      };
      if (typeof video.requestVideoFrameCallback === 'function') video.requestVideoFrameCallback(showVideo);
      else requestAnimationFrame(showVideo);
    };
    video.addEventListener('playing', () => {
      this.setMediaToggle(true);
      markRenderedFrame();
    }, { signal });
    video.addEventListener('pause', () => {
      if (video === this.backgroundVideo) this.setMediaToggle(false);
    }, { signal });
    const fallBackToPoster = () => {
      if (video !== this.backgroundVideo) return;
      this.mediaController?.abort();
      this.mediaController = null;
      this.backgroundVideo = null;
      video.remove();
      app.dataset.media = 'image';
      toggle.hidden = true;
    };
    video.addEventListener('error', fallBackToPoster, { signal });
    let failedSources = 0;
    mediaSources.forEach((source) => source.addEventListener('error', () => {
      failedSources += 1;
      if (failedSources === mediaSources.length) fallBackToPoster();
    }, { signal }));
    this.setMediaToggle(false);
    if (!this.backgroundPausedByUser) {
      video.play().catch(() => {
        if (video === this.backgroundVideo) this.setMediaToggle(false);
      });
    }
  }

  async loadLockedDraw(connectionToken, signal) {
    this.prepareForLoad();
    try {
      const manifestUrl = assertAllowedStaticUrl(
        APP_CONFIG.staticData.activeDrawManifestPath,
        APP_CONFIG.staticData.baseUrl,
        'MANIFEST_ORIGIN',
      );
      const manifest = await jsonResponse(manifestUrl, {
        label: 'Manifest žrebovaní',
        code: 'MANIFEST',
        signal,
      });
      const validDrawPath = (value) => typeof value === 'string' && /^\.\/draws\/[a-z0-9-]+\.json$/.test(value);
      if (
        manifest.schemaVersion !== 1
        || !validDrawPath(manifest.activeDraw)
        || !Array.isArray(manifest.archivedDraws)
        || !manifest.archivedDraws.every(validDrawPath)
        || new Set(manifest.archivedDraws).size !== manifest.archivedDraws.length
        || manifest.archivedDraws.includes(manifest.activeDraw)
      ) {
        throw new DrawIntegrityError('Manifest aktívneho žrebovania je neplatný.', 'MANIFEST_INVALID');
      }
      const configUrl = assertAllowedStaticUrl(manifest.activeDraw, manifestUrl, 'CONFIG_ORIGIN');
      const config = await jsonResponse(configUrl, {
        label: 'Konfigurácia žrebovania',
        code: 'CONFIG',
        signal,
      });
      const lock = APP_CONFIG.drawLocks[config.id];
      validateDrawConfig(config, lock);
      const entriesUrl = assertAllowedStaticUrl(config.entries.url, configUrl, 'ENTRIES_ORIGIN');
      const entriesBytes = await staticBytes(entriesUrl, {
        accept: 'text/plain',
        label: 'entries.txt',
        code: 'ENTRIES',
        signal,
      });
      const entriesData = await verifyEntries(entriesBytes, config);
      if (signal.aborted || connectionToken !== this.connectionToken || !this.isConnected) return;
      this.manifest = manifest;
      this.config = config;
      this.entriesData = entriesData;
      this.entriesUrl = entriesUrl.href;
      this.updateEntriesView();
      this.updateArchiveView();
      this.updateAuditView();
      this.startClock();
    } catch (error) {
      if (error?.name === 'AbortError' || signal.aborted || connectionToken !== this.connectionToken) return;
      this.failClosed(error);
    }
  }

  startClock() {
    clearInterval(this.clockTimer);
    this.updateClock();
    if (this.phase !== 'countdown') return;
    this.clockTimer = setInterval(() => this.updateClock(), 250);
  }

  updateClock() {
    const target = Date.parse(this.config.drawTimeUtc);
    const state = getCountdownState(this.now(), target);
    if (state.phase === 'due') {
      clearInterval(this.clockTimer);
      if (this.phase !== 'waiting' && this.phase !== 'result') this.beginBeaconFlow();
      return;
    }
    this.setPhase('countdown', 'Odpočítavanie do transparentného žrebovania.');
    for (const key of ['days', 'hours', 'minutes', 'seconds']) {
      this.shadowRoot.querySelector(`[data-count="${key}"]`).textContent = pad(state[key]);
    }
  }

  async beginBeaconFlow() {
    const token = ++this.runToken;
    this.setPhase('waiting', 'Čas žrebovania nastal. Overujem verejný kryptografický beacon.');
    let retryIndex = 0;
    while (this.isConnected && token === this.runToken) {
      try {
        const beacon = await this.beaconFetcher(this.config, { signal: this.lifecycleController?.signal });
        this.assertVerifiedBeacon(beacon);
        const result = await computeDraw({
          entries: this.entriesData.entries,
          entriesHashHex: this.entriesData.hash,
          config: this.config,
          drandRandomnessHex: beacon.randomness,
        });
        if (token !== this.runToken) return;
        this.beacon = beacon;
        this.result = result;
        this.showResult();
        return;
      } catch (error) {
        if (token !== this.runToken) return;
        if (!(error instanceof DrandUnavailableError)) {
          this.failClosed(error);
          return;
        }
        const schedule = this.config.drand.retryScheduleMs;
        const waitMs = schedule[Math.min(retryIndex, schedule.length - 1)];
        retryIndex += 1;
        this.shadowRoot.querySelector('[data-retry-note]').textContent = `Round ešte nie je dostupný. Ďalšie overenie o ${Math.ceil(waitMs / 1000)} s.`;
        try {
          await delay(waitMs, this.lifecycleController?.signal);
        } catch (delayError) {
          if (delayError?.name === 'AbortError') return;
          throw delayError;
        }
      }
    }
  }

  assertVerifiedBeacon(beacon) {
    if (!beacon || beacon.round !== this.config.drand.targetRound || beacon.verification !== 'valid') {
      throw new DrandVerificationError('Beacon nepotvrdil presný vopred určený round.');
    }
    if (!/^[0-9a-f]{64}$/.test(beacon.randomness || '') || !/^[0-9a-f]{96}$/.test(beacon.signature || '')) {
      throw new DrandVerificationError('Beacon nemá kanonický formát.');
    }
  }

  showResult() {
    this.shadowRoot.querySelector('[data-winner]').textContent = this.result.winner;
    this.shadowRoot.querySelector('[data-alternate]').textContent = this.result.firstAlternate;
    this.shadowRoot.querySelector('[data-open-order]').disabled = false;
    this.shadowRoot.querySelector('[data-reverify]').disabled = false;
    this.updateAuditView();
    this.setPhase('result', `Výsledok bol kryptograficky overený. Výherný kód je ${this.result.winner}.`);
  }

  prepareForLoad() {
    clearInterval(this.clockTimer);
    this.runToken += 1;
    this.manifest = null;
    this.config = null;
    this.entriesData = null;
    this.entriesUrl = null;
    this.clearVerifiedResult('Konfigurácia sa overuje…');
    const root = this.shadowRoot;
    root.querySelector('[data-entry-list]').replaceChildren();
    root.querySelector('[data-entries-status]').textContent = 'Vstupy sa overujú…';
    root.querySelector('[data-copy-entries]').disabled = true;
    root.querySelector('[data-download-entries]').removeAttribute('href');
    root.querySelector('[data-audit-entry-count]').textContent = '—';
    root.querySelector('[data-audit-entries-hash]').textContent = '—';
    root.querySelector('[data-audit-chain-hash]').textContent = '—';
    root.querySelector('[data-audit-round]').textContent = '—';
    root.querySelector('[data-audit-timestamp]').textContent = '—';
    root.querySelector('[data-archive-list]').replaceChildren();
    root.querySelector('[data-archive-list]').hidden = true;
    root.querySelector('[data-archive-empty]').hidden = false;
    this.setPhase('loading', 'Overujem konfiguráciu a vstupy.');
  }

  clearVerifiedResult(auditStatus = 'Výsledok zatiaľ nie je dostupný.') {
    this.beacon = null;
    this.result = null;
    const root = this.shadowRoot;
    root.querySelector('[data-winner]').textContent = 'ST-XX';
    root.querySelector('[data-alternate]').textContent = 'ST-YY';
    root.querySelector('[data-full-order]').replaceChildren();
    root.querySelector('[data-open-order]').disabled = true;
    root.querySelector('[data-reverify]').disabled = true;
    root.querySelector('[data-copy-audit]').disabled = true;
    root.querySelector('[data-audit-status]').textContent = auditStatus;
    root.querySelector('[data-audit-randomness]').textContent = 'Nie je k dispozícii';
    root.querySelector('[data-audit-signature]').textContent = 'Nie je k dispozícii';
    root.querySelector('[data-audit-verification]').textContent = 'Výsledok nie je overený';
    root.querySelector('[data-audit-seed-material]').textContent = 'STERON-DRAW-v1\n<entriesHash>\n<chainHash>\n32315212\n<drandRandomness>';
    root.querySelector('[data-audit-final-seed]').textContent = 'Nie je k dispozícii';
    root.querySelector('[data-audit-winner]').textContent = 'Nie je k dispozícii';
    root.querySelector('[data-audit-order]').textContent = 'Nie je k dispozícii';
    const orderDialog = root.querySelector('[data-order-dialog]');
    if (orderDialog.open) orderDialog.close();
  }

  failClosed(error) {
    clearInterval(this.clockTimer);
    this.runToken += 1;
    const code = error?.code || 'UNEXPECTED_ERROR';
    this.clearVerifiedResult(`Posledné overenie zlyhalo (${code}). Výsledkové údaje boli vyčistené.`);
    this.shadowRoot.querySelector('[data-error-code]').textContent = `Referenčný kód: ${code}`;
    this.setPhase('error', 'Overenie zlyhalo. Výsledok sa z bezpečnostných dôvodov nezobrazuje.');
    console.error('[STERON draw — fail closed]', code, error);
  }

  setPhase(phase, announcement = '') {
    const phaseChanged = this.phase !== phase;
    this.phase = phase;
    const app = this.shadowRoot.querySelector('.app');
    app.dataset.phase = phase;
    this.shadowRoot.querySelectorAll('.state-view').forEach((view) => { view.hidden = !view.classList.contains(`${phase}-view`); });
    if (announcement && (phaseChanged || announcement !== this.lastAnnouncement)) {
      this.shadowRoot.querySelector('.phase-announcement').textContent = announcement;
      this.lastAnnouncement = announcement;
    }
    if (phaseChanged) this.onTestState(phase);
  }

  updateAuditView() {
    if (!this.config || !this.entriesData) return;
    const root = this.shadowRoot;
    const set = (selector, value) => { root.querySelector(selector).textContent = value; };
    set('[data-audit-entry-count]', String(this.entriesData.entries.length));
    set('[data-audit-entries-hash]', this.entriesData.hash);
    set('[data-audit-chain-hash]', this.config.drand.chainHash);
    set('[data-audit-round]', this.config.drand.targetRound.toLocaleString('sk-SK'));
    set('[data-audit-timestamp]', this.config.roundTimeUtc);
    set('[data-audit-status]', 'Vstupy a konfigurácia: overené ✓');
    if (!this.beacon || !this.result) return;
    set('[data-audit-randomness]', this.beacon.randomness);
    set('[data-audit-signature]', this.beacon.signature);
    set('[data-audit-verification]', `Platný BLS podpis ✓ · ${this.beacon.relay || 'overený testovací relay'}`);
    set('[data-audit-seed-material]', this.result.seedMaterial);
    set('[data-audit-final-seed]', this.result.finalSeedHex);
    set('[data-audit-winner]', this.result.winner);
    set('[data-audit-order]', this.result.order.join(' → '));
    root.querySelector('[data-copy-audit]').disabled = false;
  }

  updateEntriesView() {
    if (!this.entriesData || !this.entriesUrl) return;
    const root = this.shadowRoot;
    root.querySelector('[data-entry-list]').replaceChildren(...this.entriesData.entries.map((code) => {
      const item = document.createElement('li');
      item.textContent = code;
      return item;
    }));
    root.querySelector('[data-entries-status]').textContent = `${this.entriesData.entries.length} kódov · SHA-256 overené ✓`;
    root.querySelector('[data-copy-entries]').disabled = false;
    root.querySelector('[data-download-entries]').href = this.entriesUrl;
  }

  updateArchiveView() {
    if (!this.manifest) return;
    const root = this.shadowRoot;
    const archived = this.manifest.archivedDraws;
    const list = root.querySelector('[data-archive-list]');
    const empty = root.querySelector('[data-archive-empty]');
    if (archived.length === 0) {
      list.replaceChildren();
      list.hidden = true;
      empty.hidden = false;
      return;
    }
    list.replaceChildren(...archived.map((path) => {
      const item = document.createElement('li');
      item.textContent = `Statická konfigurácia: ${path}`;
      return item;
    }));
    list.hidden = false;
    empty.hidden = true;
  }

  auditObject() {
    return {
      protocol: this.config.protocol,
      drawId: this.config.id,
      drawTimeUtc: this.config.drawTimeUtc,
      entries: {
        count: this.entriesData.entries.length,
        sha256: this.entriesData.hash,
        canonicalEncoding: 'UTF-8; LF; one code per line; one trailing LF',
        codes: this.entriesData.entries,
      },
      drand: {
        network: this.config.drand.network,
        chainHash: this.config.drand.chainHash,
        publicKey: this.config.drand.publicKey,
        round: this.config.drand.targetRound,
        roundTimeUtc: this.config.roundTimeUtc,
        randomness: this.beacon.randomness,
        signature: this.beacon.signature,
        verification: this.beacon.verification,
        relay: this.beacon.relay,
      },
      seed: {
        materialUtf8: this.result.seedMaterial,
        finalSha256: this.result.finalSeedHex,
        stream: 'SHA-256(rawFinalSeed || uint64be(counter)), counter starts at 0',
      },
      algorithm: 'Fisher-Yates with rejection sampling from big-endian uint32 values',
      winner: this.result.winner,
      order: this.result.order,
    };
  }

  async reverify(button) {
    if (!this.result || button.disabled) return;
    const connectionToken = this.connectionToken;
    const originalText = button.textContent;
    button.disabled = true;
    button.textContent = 'Overujem…';
    try {
      const beacon = await this.beaconFetcher(this.config, { signal: this.lifecycleController?.signal });
      if (!this.isConnected || connectionToken !== this.connectionToken) return;
      this.assertVerifiedBeacon(beacon);
      const recomputed = await computeDraw({
        entries: this.entriesData.entries,
        entriesHashHex: this.entriesData.hash,
        config: this.config,
        drandRandomnessHex: beacon.randomness,
      });
      if (!this.isConnected || connectionToken !== this.connectionToken) return;
      if (recomputed.finalSeedHex !== this.result.finalSeedHex || recomputed.order.join('\n') !== this.result.order.join('\n')) {
        throw new DrandVerificationError('Opakovaný výpočet sa nezhoduje s pôvodným výsledkom.');
      }
      this.beacon = beacon;
      this.result = recomputed;
      this.updateAuditView();
      this.showToast('Overenie prebehlo znova: rovnaký round, podpis aj výsledok ✓');
      this.openDialog(this.shadowRoot.querySelector('[data-audit-dialog]'), button);
    } catch (error) {
      if (!this.isConnected || connectionToken !== this.connectionToken || error?.name === 'AbortError') return;
      if (error instanceof DrandUnavailableError) {
        this.showToast('Oficiálne relaye sú momentálne nedostupné. Zobrazený výsledok sa nezmenil.');
      } else {
        this.failClosed(error);
      }
    } finally {
      if (button.isConnected && connectionToken === this.connectionToken) {
        button.disabled = !this.result;
        button.textContent = originalText;
      }
    }
  }

  openOrder(trigger) {
    if (!this.result) return;
    const list = this.shadowRoot.querySelector('[data-full-order]');
    list.replaceChildren(...this.result.order.map((code, index) => {
      const item = document.createElement('li');
      const position = document.createElement('span');
      const value = document.createElement('strong');
      const label = document.createElement('small');
      position.textContent = String(index + 1).padStart(2, '0');
      value.textContent = code;
      label.textContent = index === 0 ? 'VÝHERCA' : `${index}. NÁHRADNÍK`;
      item.append(position, value, label);
      return item;
    }));
    this.openDialog(this.shadowRoot.querySelector('[data-order-dialog]'), trigger);
  }

  openDialog(dialog, trigger) {
    this.closePopover(false);
    this.lastDialogTrigger = trigger || document.activeElement;
    if (!dialog.open) dialog.showModal();
    requestAnimationFrame(() => dialog.querySelector('[data-close-dialog]')?.focus());
  }

  closeDialog(dialog) {
    if (dialog?.open) dialog.close();
  }

  restoreFocus(element) {
    if (!element?.isConnected) return;
    const suppressPopover = element.matches?.('[data-info]');
    if (suppressPopover) this.suppressPopoverFocus = true;
    element.focus({ preventScroll: true });
    if (suppressPopover) queueMicrotask(() => { this.suppressPopoverFocus = false; });
  }

  async copyAudit(button) {
    if (!this.result) return;
    const text = JSON.stringify(this.auditObject(), null, 2);
    await this.copyText(text);
    const label = button.textContent;
    button.textContent = 'Audit skopírovaný ✓';
    clearTimeout(this.buttonTimer);
    this.buttonTimer = setTimeout(() => { button.textContent = label; }, 1800);
  }

  async copyEntries(button) {
    if (!this.entriesData) return;
    await this.copyText(`${this.entriesData.entries.join('\n')}\n`);
    const label = button.textContent;
    button.textContent = 'Zoznam skopírovaný ✓';
    clearTimeout(this.buttonTimer);
    this.buttonTimer = setTimeout(() => { button.textContent = label; }, 1800);
  }

  async copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      this.shadowRoot.append(textarea);
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
    }
  }

  openPopover(button, focusPanel) {
    clearTimeout(this.popoverTimer);
    const key = button.dataset.info;
    const content = INFO_CONTENT[key];
    if (!content) return;
    this.shadowRoot.querySelectorAll('[data-info]').forEach((trigger) => trigger.setAttribute('aria-expanded', 'false'));
    this.activeInfoTrigger = button;
    button.setAttribute('aria-expanded', 'true');
    const root = this.shadowRoot;
    const popover = root.querySelector('.info-popover');
    root.querySelector('[data-popover-eyebrow]').textContent = content.eyebrow;
    root.querySelector('[data-popover-title]').textContent = content.title;
    root.querySelector('[data-popover-text]').textContent = content.text;
    root.querySelector('[data-popover-list]').replaceChildren(...content.bullets.map((text) => {
      const item = document.createElement('li');
      item.textContent = text;
      return item;
    }));
    root.querySelector('[data-popover-deep]').dataset.section = content.section;
    popover.hidden = false;
    root.querySelector('[data-popover-backdrop]').hidden = false;
    if (this.finePointer.matches) this.positionPopover(button, popover);
    else this.clearPopoverPosition(popover);
    if (focusPanel) requestAnimationFrame(() => {
      if (!popover.hidden && this.activeInfoTrigger === button) root.querySelector('[data-close-popover]').focus({ preventScroll: true });
    });
  }

  positionPopover(button, popover) {
    const trigger = button.getBoundingClientRect();
    const margin = 14;
    const width = Math.min(380, innerWidth - (margin * 2));
    popover.style.width = `${width}px`;
    let left = Math.max(margin, Math.min(trigger.right - width, innerWidth - width - margin));
    let top = trigger.bottom + 12;
    const height = popover.getBoundingClientRect().height;
    if (top + height > innerHeight - margin) top = Math.max(margin, trigger.top - height - 12);
    popover.style.left = `${left}px`;
    popover.style.top = `${top}px`;
  }

  clearPopoverPosition(popover) {
    popover.style.removeProperty('left');
    popover.style.removeProperty('top');
    popover.style.removeProperty('width');
  }

  schedulePopoverClose() {
    if (!this.finePointer.matches) return;
    clearTimeout(this.popoverTimer);
    this.popoverTimer = setTimeout(() => this.closePopover(false), 220);
  }

  closePopover(returnFocus) {
    clearTimeout(this.popoverTimer);
    const trigger = this.activeInfoTrigger;
    this.activeInfoTrigger = null;
    this.pointerDownTrigger = null;
    const popover = this.shadowRoot.querySelector('.info-popover');
    popover.hidden = true;
    this.shadowRoot.querySelector('[data-popover-backdrop]').hidden = true;
    this.clearPopoverPosition(popover);
    this.shadowRoot.querySelectorAll('[data-info]').forEach((button) => button.setAttribute('aria-expanded', 'false'));
    if (returnFocus) this.restoreFocus(trigger);
  }

  showToast(message) {
    const toast = this.shadowRoot.querySelector('[data-toast]');
    toast.textContent = message;
    toast.hidden = false;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => { toast.hidden = true; }, 4200);
  }
}

if (!customElements.get('steron-draw-app')) customElements.define('steron-draw-app', SteronDrawApp);

export { SteronDrawApp };
